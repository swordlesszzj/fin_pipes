#pragma once
#include <cstring>
#include <cmath>
#include <iostream>

void symmetry(double a[][12], double b);
void Multi(double a[][12], double b[][12], double c[][12], double MultiResult[][12]);
